# AML


## Установка

> git submodule init; git submodule update
> bundle

## Развертывание

Для релиза используем `./release`

## Разработка

* Подключить `overcommit` 

## Спеки

* https://docs.google.com/document/d/1-IrRMo0Uzk226cSnx_EDOtX7yhNYZ0u15mBELKl-uMo/edit#
* https://docs.google.com/drawings/d/1LREdUE5JEQOocxMshyIsecbMbXhB6l48E5NQsmyJGxU/edit?usp=sharing
