require 'rails_helper'

RSpec.describe ClientDecorator do
end
