require 'rails_helper'

RSpec.describe OrderDecorator do
end
