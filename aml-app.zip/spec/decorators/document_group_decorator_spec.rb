require 'rails_helper'

RSpec.describe DocumentGroupDecorator do
end
