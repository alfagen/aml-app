module AML
  class StatusAuthorizer < ApplicationAuthorizer
  end
end
