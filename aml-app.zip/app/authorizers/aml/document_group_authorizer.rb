module AML
  class DocumentGroupAuthorizer < ApplicationAuthorizer
  end
end
