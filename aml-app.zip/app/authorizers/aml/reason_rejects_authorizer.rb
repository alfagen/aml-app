module AML
  class ReasonRejectAuthorizer < ApplicationAuthorizer
  end
end
