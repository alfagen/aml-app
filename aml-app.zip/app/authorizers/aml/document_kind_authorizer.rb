module AML
  class DocumentKindAuthorizer < ApplicationAuthorizer
  end
end
