module AML
  class DocumentKindFieldDefinitionAuthorizer < DocumentKindAuthorizer
  end
end
