# frozen_string_literal: true

require 'semver'
AppVersion = SemVer.find
