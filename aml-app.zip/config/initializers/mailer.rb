Rails.application.config.action_mailer.logger = Rails.logger
