# frozen_string_literal: true

# SimpleForm::Inputs::Base.send(:include, SimpleForm::Components::LabelTips)
